from django import forms

class MyFileForm(forms.Form):    
    file=forms.FileField(widget=forms.ClearableFileInput(attrs={'class':'form-control','allow_multiple_selected':True}))